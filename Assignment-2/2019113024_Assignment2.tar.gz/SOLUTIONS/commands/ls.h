#ifndef LS_H
#define LS_H

void ls(char *arr[]);
#endif