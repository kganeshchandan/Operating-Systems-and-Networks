#ifndef PWD_H
#define PWD_H
void pwd(char *arr[], char *home);

#endif