#ifndef ECHO_H
#define ECHO_H
void echo(char *arr[]);

#endif