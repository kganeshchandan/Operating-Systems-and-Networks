#ifndef FEXEC_H
#define FEXEC_H

void fexec(char *arr[]);
#endif