#ifndef FG_H
#define GH_H

void fg(char *arr[]);
#endif