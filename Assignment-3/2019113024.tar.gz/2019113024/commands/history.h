#ifndef HISTORY_H
#define HISTORY_H
void history(char *c_arr[], char *HIST_PATH);
void add_to_hist(char *input, char *HIST_PATH);
#endif
