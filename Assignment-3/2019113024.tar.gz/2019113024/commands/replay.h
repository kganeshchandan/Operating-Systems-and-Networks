#ifndef REPLAY_H
#define REPLAY_H

void replay(char *arr[]);

#endif