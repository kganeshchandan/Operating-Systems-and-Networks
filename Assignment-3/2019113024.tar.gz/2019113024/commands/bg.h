#ifndef BG_H
#define BG_H

void bg(char *arr[]);
#endif