#ifndef SIG_H
#define SIG_H
void sig(char *arr[]);

#endif