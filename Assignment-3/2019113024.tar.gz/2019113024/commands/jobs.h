#ifndef JOBS_H
#define JOBS_H

void jobs(char *arr[]);
int compare(const void *a, const void *b);
#endif