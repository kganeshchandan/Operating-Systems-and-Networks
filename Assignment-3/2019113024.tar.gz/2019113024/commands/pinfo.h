#ifndef PINFO_H
#define PINFO_H
void pinfo(char *arr[]);
#endif